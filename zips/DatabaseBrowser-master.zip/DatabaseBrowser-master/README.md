DatabaseBrowser
===============

SQLite data base browser in PySide
